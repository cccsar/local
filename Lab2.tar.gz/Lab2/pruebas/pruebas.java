import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class pruebas {
    public static void main(String args[]) {
        try{
            String arch = args[0];
            BufferedReader reader = new BufferedReader(new FileReader(arch));
            String s = reader.readLine();
            
            int nroV;
            nroV = Integer.parseInt(s);
            
            s= reader.readLine();
            int nroL;
            nroL = Integer.parseInt(s);

            for (int i=0;i<nroL ;i++ ) {
                s = reader.readLine();
                char a = s.charAt(0);
                char b = s.charAt(s.length()-1);
                int x = Character.getNumericValue(a);
                int y = Character.getNumericValue(b);  
                System.out.println(x);
                System.out.println(y);
            }
            
	        }	
	    
        catch(IOException e){
            System.out.println("error");
        }
    }
}
