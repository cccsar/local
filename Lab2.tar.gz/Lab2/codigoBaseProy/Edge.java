/**
 * 
 */

public interface Edge
{
  public Pair<Node,Node> getExtremes();

  @Override
  public String toString();
}
