/**
 * 
 */

import java.lang.UnsupportedOperationException;

public class Node
{
  protected int id_;
  
  public Node(int id) {
      throw new UnsupportedOperationException();
  }

  public int getId() {
      throw new UnsupportedOperationException();
  }

  @Override
  public String toString() { 
      throw new UnsupportedOperationException();
  }
}
