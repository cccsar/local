/**
 *
 */

import java.lang.UnsupportedOperationException;

public class Arris implements Edge
{
  private Node u_;
  private Node v_;
  
  public Arris(Node u, Node v) {
      throw new UnsupportedOperationException();
  }

  public Pair<Node,Node> getExtremes() {
      throw new UnsupportedOperationException();
  }

  public String toString() {
      throw new UnsupportedOperationException();
  }
}
